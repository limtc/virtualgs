// GScript BASIC Commands

inverse
print ":             :"
print " GScript BASIC "
print ":             :"
normal
print ""

print "GScript BASIC = Applesoft BASIC + JavaScript."
print "Works with Safari, Firefox, Chrome, iPhone and iPod touch."
print ""
print ""

inverse
print " Command "
normal

print "rnd(number)"
print "int(number)"
print "wait function-name, number-of-seconds"
print "loop function-name, frame-rate"
print "endLoop"
print "call function-name"
print "onEvent event call function-name"
print "beep"
print "play sound"
print ""
print ""

inverse
print " Loop "
normal

print "for variable = start to end {}"
print "for variable = start to end step increment {}"
print "for (variable in array) {}"
print "while (condition) {}"
print "do {} while (condition)"




