// Super Hires Commands

inverse
print ":                        :"
print " Super Hires Graphic Mode "
print ":                        :"
normal

print ""
print "Super Hires graphic mode has the resolution of 640x400."
print "This is the improvement of the Apple IIGS graphic modes."
print ""
print ""

inverse
print " Command "
normal
print "hgr"
print "hcolor = 0 to 15 or color-name"
print "hplot x, y"
print "hplot x1, y1 to x2, y2"
print "draw image at x, y"
print "hprint text at x, y"
print "rect x, y, width, height"
print "oval x, y, width, height"
print "circle x, y, radius"
print ""
print ""

inverse
print " Colors "
normal
print "You can use color 0-15 of the Apple IIGS color palette."
print "You can also use color names like white, red, blue, etc."