// Lores Commands

inverse
print ":                  :"
print " Lores Graphic Mode "
print ":                  :"
normal

print ""
print "Lores graphic mode has the resolution of 40x40."
print "This is one of the original graphic modes on Apple II."
print ""
print ""

inverse
print " Command "
normal
print "gr"
print "color = 0 to 15 or color-name"
print "plot x, y"
print "hlin x1, x2 at y"
print "vlin y1, y2 at x"
print ""
print ""

inverse
print " Colors "
normal
print "0: black, 1: red, 2: dark blue, 3: violet"
print "4: dark green 5: gray, 6: blue, 7: light blue"
print "8: brown, 9: orange, 10: dark gray, 11: pink"
print "12: bright green, 13: yellow, 14: aqua, 15: white"

print ""
print ""
print "By John B. Matthews and Thye Chean"
print "http://home.woh.rr.com/jbmatthews/"