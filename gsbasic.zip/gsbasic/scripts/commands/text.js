// GScript BASIC Commands

inverse
print ":         :"
print " Text Mode "
print ":         :"
normal
print ""

print "GScript BASIC allows you to use one of the 3 modes:"
print "Text mode (default), Super Hires or Lores graphic modes."
print "In graphic modes, the text will be shown at the bottom."
print ""
print ""

inverse
print " Command "
normal

print "print text"
print "home"
print "normal"
print "inverse"
print "spc(number)"
print "asc(text)"
print "char(code)"
print ""
print ""

inverse
print " Text Style "
normal
print "All the text are in fixed size, with 2 different styles."
print "Normal text will show in white on blue background."
print "Inverse text will show in blue on white background."




