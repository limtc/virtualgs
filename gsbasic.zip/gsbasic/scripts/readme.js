// Readme

inverse
print ":             :"
print " GScript BASIC "
print ":             :"
normal
print ""
print ""

inverse
print " What is GScript BASIC? "
normal

print "Modern Applesoft-inspired BASIC language for the web."
print "Virtual Apple IIGS with 640x400 Super Hires and Lores."
print "Works on Safari, Firefox, Chrome, iPhone and iPod touch."
print ""
print ""

inverse
print " How to run the script? "
normal

print "You can load and save a script directly in the browser."
print "The script will be save in the browser cookies."
print ""
print "You can also create a script in any text editor"
print "and save the file ends with .js in the scripts folder."
print "Run GScript BASIC and enter the script name to run."
print ""
print ""

inverse
print " Note "
normal

print "You can also make the script into a web application"
print "by writing a HTML file (check demo.html for example)."
print ""

print "For more information:"
print "http://virtualgs.larwe.com/Virtual_GS/GScript_BASIC.html"
