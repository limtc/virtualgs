// UFO - by Lim Thye Chean

hgr

inverse
print " UFO "
normal
print "This program demonstrate the circle and oval commands."

for i = 0 to 99 {
    hcolor = rnd(15) + 1
    hplot rnd(640), rnd(400)
}

for i = 0 to 9 {
    x = rnd(600) + 20
    y = rnd(300) + 50
    
    hcolor = rnd(15) + 1
    circle x, y, 25

    hcolor = rnd(15) + 1
    oval x - 50, y + 10, 100, 20
}